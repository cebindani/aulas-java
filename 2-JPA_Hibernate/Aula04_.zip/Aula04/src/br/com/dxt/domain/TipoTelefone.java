package br.com.dxt.domain;

public enum TipoTelefone {
	CEL, FIXO, FAX
}
