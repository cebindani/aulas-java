package br.com.dxt.domain;

public enum UF {
	SP, RJ, MG, RS	

}
