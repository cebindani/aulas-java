package br.com.dxt.domain;

public enum TipoInvest {
	Poupanca, ContaCorrente, TesouroDireto, CDB, Acoes
}
