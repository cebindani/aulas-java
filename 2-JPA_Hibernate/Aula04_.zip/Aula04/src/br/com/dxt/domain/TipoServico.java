package br.com.dxt.domain;

public enum TipoServico {
	VIP, AtendimentoPessoal, Pagamento, AberturaConta, FechamentoConta
}
