package com.dxt.domain;

import javax.persistence.Entity;

@Entity
public class Carro extends Veiculo{
	
	public String cv;

}
