package com.dxt.domain;

import javax.persistence.Entity;


@Entity
public class Moto extends Veiculo {
	
	public String cc;
	
	

}
